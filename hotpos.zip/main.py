import sys

from hotpos.application import Application
from qt_material import apply_stylesheet


if __name__ == "__main__":
    app = Application(sys.argv)
    try:
        apply_stylesheet(app, theme='dark_blue.xml')
    except:
        pass
    app.start()
    sys.exit(app.exec_())
