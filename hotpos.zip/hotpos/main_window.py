from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout

from .pages.login import LoginPage
from .pages.home import HomePage
from .pages.reservation import ReservationPage
from .pages.table import TablePage
from .pages.take_away import TakeAwayPage
from .pages.order_list import OrderListPage
from .pages.end_of_day import EndOfDayPage
from .pages.main_reading import MainReadingPage
from .models import ORDER_TYPES
from .navigation import NavigationWidget
from .config import ORDER_STATUS, WINDOW_MIN_SIZE, APP_NAME, RES_PATH


class MainWindow(QWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.app = QApplication.instance()

        self.setWindowTitle(APP_NAME)
        self.setWindowFlags(Qt.CustomizeWindowHint | Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon(str(RES_PATH / 'icon.png')))
        self.setMinimumSize(*WINDOW_MIN_SIZE)

        root_layout = QVBoxLayout()
        self.setLayout(root_layout)

        self.navigation = NavigationWidget()
        root_layout.addWidget(self.navigation, 0)

        body = QVBoxLayout()
        root_layout.addLayout(body, 1)

        self.login_page = LoginPage()
        body.addWidget(self.login_page)
        self.home_page = HomePage()
        body.addWidget(self.home_page)
        self.take_away_page = TakeAwayPage()
        body.addWidget(self.take_away_page)
        self.table_page = TablePage()
        body.addWidget(self.table_page)
        self.reservation_page = ReservationPage()
        body.addWidget(self.reservation_page)
        self.end_of_day_page = EndOfDayPage()
        body.addWidget(self.end_of_day_page)
        self.main_reading_page = MainReadingPage()
        body.addWidget(self.main_reading_page)

        self.order_list_page = OrderListPage()
        body.addWidget(self.order_list_page)

        if self.app.backend().checkToken():
            self.showPage('home')
        else:
            self.showPage('login')

        self.take_away_page.loadRemoteData()

    def showPage(self, page_name: str):
        self.login_page.hide()
        self.home_page.hide()
        self.take_away_page.hide()
        self.table_page.hide()
        self.reservation_page.hide()
        self.order_list_page.hide()
        self.end_of_day_page.hide()
        self.main_reading_page.hide()

        if page_name == 'login':
            self.navigation.hide()
            self.login_page.show()
            return

        self.navigation.show()
        if page_name == 'home':
            self.navigation.setCurrentTab('home')
            self.home_page.show()
        elif page_name == 'take_away':
            self.take_away_page.show()
            self.take_away_page.order_widget.prepareNewOrder()
        elif page_name == 'delivery':
            self.take_away_page.show()
            self.take_away_page.order_widget.prepareNewOrder(is_delivery=True)
        elif page_name == 'table':
            self.table_page.show()
        elif page_name == 'reservation':
            self.reservation_page.show()
        elif page_name == 'order-list-older-sales':
            self.order_list_page.loadData(order_status=ORDER_STATUS.PAID)
            self.order_list_page.show()
        elif page_name == 'order-list-open-delivery':
            self.order_list_page.loadData(order_type=ORDER_TYPES.DELIVERY, order_status=ORDER_STATUS.NEW)
            self.order_list_page.show()
        elif page_name == 'order-list-open-tables':
            self.order_list_page.loadData(order_type=ORDER_TYPES.TABLE, order_status=ORDER_STATUS.NEW)
            self.order_list_page.show()
        elif page_name == 'end-of-day':
            self.end_of_day_page.show()
            self.end_of_day_page.loadData()
        elif page_name == 'main-reading':
            self.main_reading_page.show()
            self.main_reading_page.loadData()
