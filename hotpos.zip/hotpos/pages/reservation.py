from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QGroupBox

from ..widgets.table import ReservationTableWidget


class ReservationPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.app = QApplication.instance()

        root_layout = QVBoxLayout(self)

        self.gb = QGroupBox("Reservation")
        root_layout.addWidget(self.gb)
        gb_root = QVBoxLayout(self.gb)
        self.reservation_table = ReservationTableWidget()
        gb_root.addWidget(self.reservation_table)
