from hotpos.config import ORDER_STATUS
from hotpos.widgets.label import LabelWidget
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QHBoxLayout, QPushButton, QWidget, QVBoxLayout, QGroupBox, QScrollArea, QMessageBox

from ..helpers.summarizer import getSummaries


class EndOfDayPage(QWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.app = QApplication.instance()

        self.root_layout = QVBoxLayout(self)

        layout = QHBoxLayout()
        button = QPushButton("End of Day")
        button.clicked.connect(self.onEndOfDayClick)
        layout.addWidget(button)
        button = QPushButton("Main Reading Print")
        button.clicked.connect(lambda: self.app.main_window.navigation.showMainReadingPage())
        layout.addWidget(button)
        self.root_layout.addLayout(layout, 0)

        self.summaries_widget = None
        self.order_list = []

    def loadData(self):
        self.order_list = self.app.backend().getOrderList()
        category_data = self.app.backend().getCategoryData()
        summary_list = getSummaries(self.order_list, category_data)

        if self.summaries_widget:
            self.summaries_widget.setParent(None)

        self.summaries_widget = QWidget()
        self.root_layout.addWidget(self.summaries_widget)
        summaries_layout = QHBoxLayout(self.summaries_widget)

        for summary in summary_list:
            gb = QGroupBox(summary[0])
            summaries_layout.addWidget(gb)
            gb_layout = QVBoxLayout(gb)

            summary_widget = QWidget()
            summary_layout = QVBoxLayout(summary_widget)

            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(summary_widget)
            gb_layout.addWidget(scroll)

            _round = lambda v: round(v, 2) if type(v) == float else v

            for line in summary[1]:
                line_layout = QHBoxLayout()
                summary_layout.addLayout(line_layout, 0)
                label = LabelWidget(str(line[0]))
                line_layout.addWidget(label)
                value = LabelWidget(str(_round(line[1])))
                value.setAlignment(Qt.AlignRight | Qt.AlignCenter)
                line_layout.addWidget(value)
            summary_layout.addWidget(QWidget(), 1)

    def onEndOfDayClick(self):
        if ORDER_STATUS.NEW in list(map(lambda o: o.status, self.order_list)):
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Unable")
            msg.setInformativeText('Please cashout all open sales to perform end of day.')
            msg.setWindowTitle("Error")
            msg.exec_()
            self.app.main_window.navigation.showOpenDeliveryPage()
        else:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Question)
            result = msg.question(self.app.main_window, 'Are you sure?', 'Do you wish to perform End Of Day?', QMessageBox.Yes | QMessageBox.No)
            if result == QMessageBox.Yes:
                self.app.backend().processEndOfDay()
                self._refresh()

    def _refresh(self):
        self.loadData()
