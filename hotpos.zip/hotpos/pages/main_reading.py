from datetime import datetime

from PyQt5.QtWidgets import QApplication, QVBoxLayout, QWidget
from PyQt5.QtWebEngineWidgets import QWebEngineView

from ..backend_facade import BackendFacade
from ..config import DIALOG_MIN_SIZE_A, MAIN_READING_TEMPLATE, DATETIME_FORMAT
from ..helpers.print_handler import PrintHandler


LOADING_TEMPLATE = """
<h3>Loading ...</h3>
"""


class MainReadingPage(QWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.backend: BackendFacade = QApplication.instance().backend()

        self.initUI()

    def loadData(self):
        html = str(MAIN_READING_TEMPLATE)

        info = self.backend.getMainReadingInfo()
        info_html = ""
        if info.visibility.show_branch_name:
            info_html += "<p>%s</p>" % info.branch_name
        if info.visibility.show_company_name:
            info_html += "<p>%s</p>" % info.company_name
        if info.visibility.show_branch_address:
            info_html += "<p>%s</p>" % info.branch_address
        if info.visibility.show_phone_number:
            info_html += "<p>%s</p>" % info.branch_phone_number
        if info.visibility.show_vat_info:
            info_html += "<p>VAT #: %s</p>" % ("" if info.company_tax_number is not None else info.company_tax_number)
        html = html.replace('__INFO__', info_html)
        html = html.replace('__DATETIME__', datetime.today().strftime(DATETIME_FORMAT))
        self.webview.setHtml(html)

    def printPreview(self):
        printHandler = PrintHandler()
        printHandler.setPage(self.webview.page())
        printHandler.printPreview()

    def initUI(self):
        self.setMinimumSize(*DIALOG_MIN_SIZE_A)
        self.setWindowTitle("Main Reading")

        root_layout = QVBoxLayout(self)

        self.webview = QWebEngineView()
        self.webview.setHtml(LOADING_TEMPLATE)

        root_layout.addWidget(self.webview)
