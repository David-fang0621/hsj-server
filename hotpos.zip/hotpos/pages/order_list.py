from typing import List

from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QGroupBox

from ..config import ORDER_TYPES
from ..dialogs.order_details import OrderDetailsDialog
from ..models import Order
from ..widgets.table import OrderCollectionTableWidget


class OrderListPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.app = QApplication.instance()

        self.order_list: List[Order] = []
        self.order_type = None
        self.order_status = None

        root_layout = QVBoxLayout(self)

        self.gb = QGroupBox("Order List")
        root_layout.addWidget(self.gb)
        gb_root = QVBoxLayout(self.gb)
        self.late_orders_table = OrderCollectionTableWidget()
        self.late_orders_table.doubleClicked.connect(self._openOrderDetailsDialog)
        gb_root.addWidget(self.late_orders_table)

    def loadData(self, order_type: int=None, order_status: int=None):
        self.order_type, self.order_status = order_type, order_status
        self._setTitle(order_type)
        self.order_list = self.app.backend().getOrderList()
        if order_type is not None:
            self.order_list = list(filter(lambda order: order.type == order_type, self.order_list))
        if order_status is not None:
            self.order_list = list(filter(lambda order: order.status == order_status, self.order_list))
        def toDataItem(order: Order):
            return [
                    order.id,
                    'Delivery', order.customer.first_name + ' ' + order.customer.last_name if order.customer else '',
                    order.created_at,
                    order.total
            ]
        data = list(map(toDataItem, self.order_list))
        self.late_orders_table.setData(data)

    def _setTitle(self, order_type: str):
        if order_type == ORDER_TYPES.DELIVERY:
            self.gb.setTitle("Open Delivery Orders")
        elif order_type == ORDER_TYPES.TAKEAWAY:
            self.gb.setTitle("Preview Older Sales")
        elif order_type == ORDER_TYPES.TABLE:
            self.gb.setTitle("Open Tables")
        else:
            self.gb.setTitle("All Orders List")

    def _reload(self):
        self.loadData(order_type=self.order_type, order_status=self.order_status)

    def _openOrderDetailsDialog(self):
        row = self.late_orders_table.currentIndex().row()
        order = self.order_list[row]
        dialog = OrderDetailsDialog(order)
        if dialog.exec_():
            self._reload()
