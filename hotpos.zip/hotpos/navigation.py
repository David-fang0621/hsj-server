from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QWidget, QHBoxLayout, QPushButton, QMenu, QAction, QMessageBox

from .config import RES_PATH, SIZE_B


class NavigationWidget(QWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.app = QApplication.instance()

        self.root_layout = QHBoxLayout()
        self.setLayout(self.root_layout)

        self.addMenu()

        self.home_button = QPushButton("Home")
        self.home_button.clicked.connect(self.showHomePage)
        _styleButton(self.home_button)
        self.root_layout.addWidget(self.home_button)

        self.take_away_button = QPushButton("Take away")
        self.take_away_button.clicked.connect(self.showTakeAwayPage)
        _styleButton(self.take_away_button)
        self.root_layout.addWidget(self.take_away_button)

        self.delivery_button = QPushButton("Delivery")
        self.delivery_button.clicked.connect(self.showDeliveryPage)
        _styleButton(self.delivery_button)
        self.root_layout.addWidget(self.delivery_button)

        self.table_button = QPushButton("Table")
        self.table_button.clicked.connect(self.showTablePage)
        _styleButton(self.table_button)
        self.root_layout.addWidget(self.table_button)

        self.reservation_button = QPushButton("Reservation")
        self.reservation_button.clicked.connect(self.showReservationPage)
        _styleButton(self.reservation_button)
        self.root_layout.addWidget(self.reservation_button)

    def addMenu(self):
        menu = QMenu(self)
        button = QPushButton()
        button.setIcon(QIcon(str(RES_PATH / 'icon-menu.png')))
        _styleButton(button)
        button.setFixedWidth(SIZE_B)
        button.setMenu(menu)
        self.root_layout.addWidget(button)

        action = QAction(self)
        action.setText("Preview Older Sales")
        action.triggered.connect(self.showOlderSalesPage)
        menu.addAction(action)

        action = QAction(self)
        action.setText("Open Delivery Orders")
        action.triggered.connect(self.showOpenDeliveryPage)
        menu.addAction(action)

        action = QAction(self)
        action.setText("Open Tables")
        action.triggered.connect(self.showOpenTablesPage)
        menu.addAction(action)

        action = QAction(self)
        action.setText("Main Reading")
        action.triggered.connect(self.showMainReadingPage)
        menu.addAction(action)

        action = QAction(self)
        action.setText("Open Tables Reading")
        action.setEnabled(False)
        menu.addAction(action)

        menu.addSeparator()

        action = QAction(self)
        action.setText("Transfer Items")
        action.setEnabled(False)
        menu.addAction(action)

        action = QAction(self)
        action.setText("End of Day")
        action.triggered.connect(self.showEndOfDayPage)
        menu.addAction(action)

        action = QAction(self)
        action.setText("Screen Setup")
        action.setEnabled(False)
        menu.addAction(action)

        menu.addSeparator()

        action = QAction(self)
        action.setText("Log Out")
        action.triggered.connect(self.app.logOut)
        menu.addAction(action)

        action = QAction(self)
        action.setText("Exit")
        action.triggered.connect(self.app.exit)
        menu.addAction(action)

    def showHomePage(self):
        if self.app.backend().isProcessEndOfDay():
            self.showEndOfDayDialog()
        else:
            self.app.main_window.showPage('home')
            self.setCurrentTab('home')

    def showTakeAwayPage(self):
        if self.app.backend().isProcessEndOfDay():
            self.showEndOfDayDialog()
        else:
            self.app.main_window.showPage('take_away')
            self.setCurrentTab('take_away')

    def showDeliveryPage(self):
        if self.app.backend().isProcessEndOfDay():
            self.showEndOfDayDialog()
        else:
            self.app.main_window.showPage('delivery')
            self.setCurrentTab('delivery')

    def showTablePage(self):
        if self.app.backend().isProcessEndOfDay():
            self.showEndOfDayDialog()
        else:
            self.app.main_window.showPage('table')
            self.setCurrentTab('table')

    def showReservationPage(self):
        if self.app.backend().isProcessEndOfDay():
            self.showEndOfDayDialog()
        else:
            self.app.main_window.showPage('reservation')
            self.setCurrentTab('reservation')

    def showOlderSalesPage(self):
        self.app.main_window.showPage('order-list-older-sales')
        self.setCurrentTab('order-list')

    def showOpenDeliveryPage(self):
        self.app.main_window.showPage('order-list-open-delivery')
        self.setCurrentTab('order_list')

    def showOpenTablesPage(self):
        self.app.main_window.showPage('order-list-open-tables')
        self.setCurrentTab('order_list')

    def showEndOfDayPage(self):
        self.app.main_window.showPage('end-of-day')
        self.setCurrentTab('end-of-day')

    def showEndOfDayDialog(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)
        msg.setText("Perform End of Day")
        msg.setInformativeText('End of day for a day was not done. Do you wish to perform end of day?')
        msg.setWindowTitle("Error")
        msg.exec_()
        self.showEndOfDayPage()

    def showMainReadingPage(self):
        self.app.main_window.showPage('main-reading')
        self.setCurrentTab('main-reading')

    def setCurrentTab(self, page_name: str):
        self.home_button.setDown(False)
        self.take_away_button.setDown(False)
        self.delivery_button.setDown(False)
        self.table_button.setDown(False)
        self.reservation_button.setDown(False)
        if page_name == 'home':
            self.home_button.setDown(True)
        elif page_name == 'take_away':
            self.take_away_button.setDown(True)
        elif page_name == 'delivery':
            self.delivery_button.setDown(True)
        elif page_name == 'table':
            self.table_button.setDown(True)
        elif page_name == 'reservation':
            self.reservation_button.setDown(True)


def _styleButton(btn: QPushButton) -> QPushButton:
    btn.setStyleSheet('height: 64px; margin-bottom: 16px;')
