from typing import Callable, List

from pydantic import BaseModel
from PyQt5.QtGui import QIcon, QMouseEvent
from PyQt5.QtWidgets import QApplication, QWidget, QHBoxLayout, QVBoxLayout, QPushButton, QScrollArea, QSizePolicy, QGroupBox

from ..config import RES_PATH, SIZE_A, SIZE_B, ORDER_TYPES, ORDER_STATUS
from ..dialogs.add_customer import AddCustomerDialog
from ..dialogs.add_discount import AddDiscountDialog
from ..dialogs.add_modifiers import AddModifiersDialog
from ..dialogs.add_promos import AddPromosDialog
from ..dialogs.edit_price import EditPriceDialog
from ..models import Cookie, Modifier, AppliedModifier, Customer, Order, Country, Discount, OrderContent, Promo
from .group_box import GroupBoxWidget
from .horizontal_spinbox import HorizontalSpinBox
from .label import LabelWidget


class ModifierCollectionWidget(QGroupBox):

    def __init__(self, applied_modifier: AppliedModifier, cookie: Cookie, parent: QWidget = None):
        super().__init__(parent=parent)

        self.applied_modifier = applied_modifier
        self.cookie = cookie

        root_layout = QHBoxLayout(self)

        name_label = LabelWidget("Quantity: %d" % self.applied_modifier.qty)
        root_layout.addWidget(name_label, 1)

        modifiers_string = ", ".join([m.modifier for m in self.applied_modifier.modifiers])
        modifier_label = LabelWidget(modifiers_string)
        root_layout.addWidget(modifier_label, 1)

        delete_button = QPushButton("")
        delete_button.setFixedHeight(SIZE_A)
        delete_button.setFixedWidth(SIZE_A)
        delete_button.setIcon(QIcon(str(RES_PATH / 'icon-delete.png')))
        delete_button.clicked.connect(self.delete)
        delete_button.setFixedWidth(SIZE_B)
        root_layout.addWidget(delete_button, 0)

    def delete(self):
        self.setParent(None)
        self.cookie.appliedModifiers.remove(self.applied_modifier)


class OrderedCookieWidget(QGroupBox):

    def __init__(self, cookie: Cookie, order: Order, calculate: Callable, parent=None):
        super().__init__(parent=parent)

        self.cookie = cookie
        self.order = order
        self.calculate = calculate

        root_layout = QVBoxLayout(self)
        self.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)

        header = QHBoxLayout()
        root_layout.addLayout(header)

        name_label = LabelWidget(self.cookie.name)
        header.addWidget(name_label, 1)

        delete_button = QPushButton("")
        delete_button.setFixedHeight(SIZE_A)
        delete_button.setFixedWidth(SIZE_A)
        delete_button.setIcon(QIcon(str(RES_PATH / 'icon-delete.png')))
        delete_button.clicked.connect(self.delete)
        delete_button.setFixedWidth(SIZE_B)
        header.addWidget(delete_button, 0)

        body = QHBoxLayout()
        root_layout.addLayout(body)

        self.quantity_spinbox = HorizontalSpinBox()
        self.quantity_spinbox.setRange(1, 100)
        self.quantity_spinbox.setValue(self.cookie.qty)
        self.quantity_spinbox.valueChanged.connect(self.onQuantityChange)
        body.addWidget(self.quantity_spinbox)

        self.price_label = LabelWidget(str(self.cookie.price)).setCenter()
        body.addWidget(self.price_label)

        button = QPushButton("+M")
        button.setFixedWidth(SIZE_B)
        if len(self.cookie.modifiers) == 0:
            button.setEnabled(False)
        else:
            button.clicked.connect(self.openAddModifiersDialog)
        body.addWidget(button)
        button = QPushButton("+P")
        button.setFixedWidth(SIZE_B)
        if len(self.cookie.promos) == 0:
            button.setEnabled(False)
        else:
            button.clicked.connect(self.openAddPromosDialog)
        body.addWidget(button)

        button = QPushButton("Edit")
        button.setFixedWidth(SIZE_B)
        button.clicked.connect(self.openEditPriceDialog)
        body.addWidget(button)

        footer = QWidget()
        root_layout.addWidget(footer)
        self.modifier_collection_container = QVBoxLayout(footer)

    def delete(self):
        self.setParent(None)
        if self.cookie in self.order.ordercontent.items:
            self.order.ordercontent.items.remove(self.cookie)
        self.calculate()

    def onQuantityChange(self):
        self.cookie.qty = self.quantity_spinbox.value()
        self.price_label.setText(str(self.cookie.price * self.cookie.qty))
        self.calculate()

    def renderModifierCollectionList(self):
        for i in reversed(range(self.modifier_collection_container.count())):
            widget = self.modifier_collection_container.itemAt(i).widget()
            if widget:
                widget.setParent(None)
        for applied_modifier in self.cookie.appliedModifiers:
            modifier_item_widget = ModifierCollectionWidget(applied_modifier, self.cookie)
            self.modifier_collection_container.addWidget(modifier_item_widget)

    def openAddModifiersDialog(self):
        dialog = AddModifiersDialog(self.cookie)
        if dialog.exec_():
            self.renderModifierCollectionList()
            self.calculate()

    def openAddPromosDialog(self):
        dialog = AddPromosDialog(self.cookie)
        if dialog.exec_():
            self.renderModifierCollectionList()
            self.calculate()

    def openEditPriceDialog(self):
        dialog = EditPriceDialog(self.cookie.price)
        if dialog.exec_():
            self.cookie.price = dialog.getPrice()
            self.price_label.setText(str(self.cookie.price * self.cookie.qty))
            self.calculate()


class OrderWidget(GroupBoxWidget):

    """
    A view class for Order model

    ...

    Attributes
    ----------
    order : Order
        Data model object
    customer_list : List[Customer]
    country_list : List[Country]
    cookie_widget_list : List[OrderedCookieWidget]
    tax : float
    order_id : int
    order_type : int

    Methods
    -------
    loadRemoteData():
        Preload customer_list, country_list, cookie_widget_list, tax from backend
    prepareNewOrder(is_delivery=False, get_new_id=False)
        Clear UI and model data for adding a new order
    addCookieItem(main_cat: int, sub_cat: int, cookie_item: int)
        Add a Cookie to the order
    calculate()
        Calculate and show on UI elements
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.app = QApplication.instance()

        self._initUI()
        self.customer_list: List[Customer] = []
        self.country_list: List[Country] = []
        self.cookie_widget_list: List[OrderedCookieWidget] = []
        self._tax: float = 0.0
        self._order_id: int = 0
        self.order_type: int = ORDER_TYPES.TAKEAWAY
        self.order: Order = None
        self._is_editing = False

    def loadRemoteData(self):
        self._is_editing = False
        self.customer_list = self.app.backend().getCustomerList()
        self._tax = self.app.backend().companyTax()
        self._order_id = self.app.backend().getNewOrderId()
        self.country_list = self.app.backend().getCountryList()

    def prepareNewOrder(self, is_delivery=False, get_new_id=False):
        for cookie_widget in self.cookie_widget_list:
            cookie_widget.delete()

        self.cookie_widget_list = []
        self.order = Order(
                ordercontent=OrderContent(items=[], combos=[]),
                sub_total=0.0,
                total=0.0,
                tax=self._tax,
                discount=Discount(amount=0.0, percentage=0.0),
                customer=None,
                id=self.app.backend().getNewOrderId() if get_new_id else self._order_id,
                type=ORDER_TYPES.DELIVERY if is_delivery else ORDER_TYPES.TAKEAWAY,
                status=ORDER_STATUS.NEW if is_delivery else ORDER_STATUS.PENDING,
                created_at=''
        )
        if self._is_editing:
            self.calculate()
        else:
            if is_delivery:
                self._openAddCustomerDialog(None)
                self.order_button.show()
            else:
                self.order_button.hide()
            self.calculate()

    def loadOrder(self, order: Order):
        self._is_editing = True
        for cookie_widget in self.cookie_widget_list:
            cookie_widget.delete()

        self._tax = order.tax
        self._order_id = order.id
        self.order_type = order.type
        self.order = order
        self.cookie_widget_list = []
        for cookie in self.order.ordercontent.items:
            cookie_widget = OrderedCookieWidget(cookie, self.order, self.calculate)
            self.cookie_list_layout.insertWidget(self.cookie_list_layout.count() - 1, cookie_widget)
            self.cookie_widget_list.append(cookie_widget)
        self.order_button.show()
        self.calculate()

    def addCookieItem(self, main_cat: int, sub_cat: int, cookie_item: int):
        _cookie = self.app.backend().getCategoryData()[main_cat]['sub_category_list'][sub_cat]['item_list'][cookie_item]
        modifier_list = []
        for m in _cookie['modifiers']:
            modifier_list.append(Modifier(**m))
        promo_list = []
        for p in _cookie['promos']:
            promo_list.append(Promo(**p))
        _cookie['kitchennote'] = ''
        cookie = Cookie(**_cookie)
        self.order.ordercontent.items.append(cookie)
        cookie_widget = OrderedCookieWidget(cookie, self.order, self.calculate)
        self.cookie_list_layout.insertWidget(self.cookie_list_layout.count() - 1, cookie_widget)
        self.cookie_widget_list.append(cookie_widget)
        self.calculate()

    def calculate(self):
        self.order.calculate()
        self.order_id_label.setText("Order ID: %d" % self.order.id)
        self.sub_total_label.setText(str(self.order.sub_total))
        self.total_label.setText(str(self.order.total))
        if self.order.discount.amount != 0:
            self.discount_button.setText(str(self.order.discount.amount))
        elif self.order.discount.percentage != 0:
            self.discount_button.setText(str(self.order.discount.percentage) + "%")
        else:
            self.discount_button.setText("+")
        if self.order.customer is None:
            self.customer_button.setText('+')
        else:
            self.customer_button.setText(self.order.customer.first_name)
        self._checkCheckoutable()

    def _checkCheckoutable(self):
        if len(self.order.ordercontent.items) == 0 or (
            self.order_type == ORDER_TYPES.DELIVERY and self.order.customer is None
        ):
            self.order_button.setEnabled(False)
            self.checkout_button.setEnabled(False)
        else:
            self.order_button.setEnabled(True)
            self.checkout_button.setEnabled(True)

    def _openAddDiscountDialog(self, e: QMouseEvent):
        dialog = AddDiscountDialog(self.order)
        if dialog.exec_():
            self.calculate()

    def _openAddCustomerDialog(self, e: QMouseEvent):
        dialog = AddCustomerDialog(self.order, self.customer_list, self.country_list)
        if dialog.exec_():
            self.calculate()

    def _onOrderClicked(self):
        self._onCheckoutClicked(is_delivery=True)

    def _onCheckoutClicked(self, is_delivery=False):
        self.app.backend().checkout(self.order.serialize(is_delivery=is_delivery), is_editing=self._is_editing, order_id=self.order.id)
        self.prepareNewOrder(is_delivery=is_delivery, get_new_id=True)
        if self._is_editing:
            self.app.main_window.navigation.showOpenDeliveryPage()
            self._is_editing = False

    def _initUI(self):
        root_layout = self.getRootLayout()

        widget = QWidget()
        layout = QHBoxLayout(widget)
        self.order_id_label = LabelWidget("Order ID:")
        layout.addWidget(self.order_id_label)
        root_layout.addWidget(widget, 0)

        cookie_list = QWidget()
        self.cookie_list_layout = QVBoxLayout(cookie_list)
        self.cookie_list_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(cookie_list)
        root_layout.addWidget(scroll)

        row_layout = QHBoxLayout()
        root_layout.addLayout(row_layout, 0)

        widget = QWidget()
        layout = QHBoxLayout(widget)
        row_layout.addWidget(widget)
        layout.addWidget(LabelWidget('Sub Total'), 1)
        self.sub_total_label = LabelWidget(str(0.0))
        layout.addWidget(self.sub_total_label, 0)

        widget = QWidget()
        layout = QHBoxLayout(widget)
        row_layout.addWidget(widget)
        layout.addWidget(LabelWidget('Tax'), 1)
        self.tax_label = LabelWidget(str(0.0))
        layout.addWidget(self.tax_label, 0)

        row_layout = QHBoxLayout()
        root_layout.addLayout(row_layout, 0)

        widget = QWidget()
        layout = QHBoxLayout(widget)
        row_layout.addWidget(widget)
        layout.addWidget(LabelWidget('Discount'), 1)
        self.discount_button = LabelWidget("+")
        self.discount_button.mousePressEvent = self._openAddDiscountDialog
        layout.addWidget(self.discount_button, 0)

        widget = QWidget()
        layout = QHBoxLayout(widget)
        row_layout.addWidget(widget)
        layout.addWidget(LabelWidget('Customer'), 1)
        self.customer_button = LabelWidget("+")
        self.customer_button.mousePressEvent = self._openAddCustomerDialog
        layout.addWidget(self.customer_button, 0)

        row = QWidget()
        row_layout = QHBoxLayout(row)
        root_layout.addWidget(row)

        layout = QHBoxLayout()
        row_layout.addLayout(layout)
        layout.addWidget(LabelWidget('Total'), 1)
        self.total_label = LabelWidget(str(0.0))
        layout.addWidget(self.total_label, 0)

        row_layout = QHBoxLayout()
        root_layout.addLayout(row_layout, 0)
        self.order_button = QPushButton("ORDER")
        self.order_button.clicked.connect(self._onOrderClicked)
        row_layout.addWidget(self.order_button, 1)
        self.checkout_button = QPushButton("CHECKOUT")
        self.checkout_button.clicked.connect(self._onCheckoutClicked)
        row_layout.addWidget(self.checkout_button, 1)
