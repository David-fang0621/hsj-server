from collections import namedtuple
import json
from pathlib import Path


APP_NAME = 'HotPOS'
VERSION = 1

SETTING_NAME = APP_NAME
SETTING_VERSION = 'qt-v1'

ROOT_PATH = Path(__file__).parent.parent
RES_PATH = ROOT_PATH / 'res'

with open(ROOT_PATH / 'config.json') as fp:
    config = json.load(fp)
    BASE_URL = config['base_url']
    API_URL = config['api_url']
    MIN_WINDOW_HEIGHT = config['min_window_height']

WINDOW_MIN_SIZE = (1024, MIN_WINDOW_HEIGHT)
DIALOG_MIN_SIZE_A = (640, MIN_WINDOW_HEIGHT)
DIALOG_MIN_SIZE_B = (300, 360)
DIALOG_MIN_SIZE_C = (300, 240)
DIALOG_MIN_SIZE_D = (440, 440)
MAIN_CAT_ICON_SIZE = (48, 48)
MAIN_CAT_LIST_WIDTH = 128
SUB_CAT_LIST_HEIGHT = 32
ITEM_ICON_SIZE = (180, 120)
SIZE_A = 24
SIZE_B = 40
SIZE_C = 96

_OrderTypes = namedtuple('_OrderTypes', ['TAKEAWAY', 'DELIVERY', 'TABLE'])
ORDER_TYPES = _OrderTypes(1, 2, 3)
_OrderStatus = namedtuple('_OrderStatus', ['NEW', 'PENDING', 'PAID', 'CANCEL'])
ORDER_STATUS = _OrderStatus(0, 1, 2, 3)

with open(RES_PATH / 'main_reading.html') as fp:
    MAIN_READING_TEMPLATE = fp.read()
DATETIME_FORMAT = "%m/%d/%Y %H:%M:%S"
