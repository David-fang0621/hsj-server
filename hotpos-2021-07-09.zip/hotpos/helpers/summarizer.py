from itertools import chain
from typing import List
from ..models import Cookie, Order


def getSummaries(orders: List[Order], category_data: List[dict]):
    no_order = len(orders) == 0
    summary = [
        [ 'First Order', '' if no_order else orders[0].created_at ],
        [ 'Last Order',  '' if no_order else orders[-1].created_at ],
        [ 'First Invoiced', '' if no_order else '#%d' % orders[0].id ],
        [ 'Last Invoiced', '' if no_order else '#%d' % orders[-1].id ],
        [ 'Number of Customers', 0 if no_order else len(orders) ],
        [ 'Grand Total', sum(map(lambda o: o.sub_total, orders)) ],
        [ 'VAT', sum(map(lambda o: o.tax, orders)) ],
        [ 'Discount', sum(map(lambda o: o.discount.amount + o.sub_total * o.discount.percentage / 100.0, orders)) ],
        [ 'Paid In', 0 ],
        [ 'Paid Out', 0 ],
        [ 'Net Total + P.In - P.Out', sum(map(lambda o: o.total, orders)) ],
        [ 'Sub Total', sum(map(lambda o: o.sub_total, orders)) ],
        [ 'Average Check', 0 if no_order else sum(map(lambda o: o.total, orders)) / len(orders) ],
    ]

    def cookie_to_price(cookie: Cookie):
        price = cookie.price * cookie.qty
        for modifier_collection in cookie.appliedModifiers:
            for modifier in modifier_collection.modifiers:
                price -= modifier.price * modifier_collection.qty
        return price
    def calculate_total(summary):
        summary.append([ 'Total', sum(map(lambda s: s[1], summary)) ])

    cookie_list = list(chain(*map(lambda o: o.ordercontent.items, orders)))

    summary_by_category = list(map(lambda category: [ category['name'], sum(map(cookie_to_price, filter(lambda c: c.category_id == category['id'] or c.category_id in [sc.get('id') for sc in category['sub_category_list']], cookie_list))) ], category_data))
    calculate_total(summary_by_category)

    summary_by_subcategory = list(map(lambda sc: [ sc['name'], sum(map(cookie_to_price, filter(lambda c: c.category_id == sc['id'], cookie_list))) ], filter(lambda sc: sc['name'] != 'All', chain(*map(lambda c: c['sub_category_list'], category_data)))))
    calculate_total(summary_by_subcategory)

    summary_by_item = list(map(lambda cookie_name: [ cookie_name, sum(map(cookie_to_price, filter(lambda c: c.name == cookie_name, cookie_list))) ], sorted(list(set(map(lambda c: c.name, cookie_list))))))
    calculate_total(summary_by_item)

    return [
        [ 'summary', summary ],
        [ 'summary_by_category', summary_by_category ],
        [ 'summary_by_subcategory', summary_by_subcategory ],
        [ 'summary_by_item', summary_by_item ],
    ]
