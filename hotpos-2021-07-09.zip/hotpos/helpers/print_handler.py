"""
https://stackoverflow.com/questions/59438021/how-do-i-create-a-print-preview-of-qwebengineview-in-pyqt5
"""

from PyQt5.QtCore import (QCoreApplication, QEventLoop, QObject, QPointF, Qt,
                       QUrl, pyqtSlot)
from PyQt5.QtGui import QKeySequence, QPainter
from PyQt5.QtPrintSupport import QPrintDialog, QPrinter, QPrintPreviewDialog
from PyQt5.QtWebEngineWidgets import QWebEnginePage, QWebEngineView
from PyQt5.QtWidgets import QApplication, QDialog, QLabel, QProgressBar, QProgressDialog, QShortcut


class PrintHandler(QObject):

    def __init__(self, parent = None):
        super().__init__(parent)
        self.m_page = None
        self.m_inPrintPreview = False
        self.app = QApplication.instance()

    def setPage(self, page):
        assert not self.m_page
        self.m_page = page
        self.m_page.printRequested.connect(self.printPreview)

    @pyqtSlot()
    def print(self):
        printer = QPrinter(QPrinter.HighResolution)
        dialog = QPrintDialog(printer, self.m_page.view())
        if dialog.exec_() != QDialog.Accepted:
            return
        self.printDocument(printer)

    @pyqtSlot()
    def printPreview(self):
        if not self.m_page:
            return
        if self.m_inPrintPreview:
            return
        self.m_inPrintPreview = True
        printer = QPrinter()
        preview = QPrintPreviewDialog(printer, self.m_page.view())

        # copied from v1.3
        rec = QApplication.desktop().screenGeometry()
        sw, sh = rec.width(), rec.height()
        w, h = 1100, 800
        x = int ( (sw - w)/2 )
        y = int ( (sh - h)/2 )
        # preview.setWindowFlags(self.app.profileDialog.windowFlags() & ~ Qt.WindowContextHelpButtonHint)
        preview.setGeometry(x, y, w, h)

        preview.paintRequested.connect(self.printDocument)
        preview.exec()
        self.m_inPrintPreview = False

    @pyqtSlot(QPrinter)
    def printDocument(self, printer):
        loop = QEventLoop()
        result = False

        def printPreview(success):
            nonlocal result
            result = success
            loop.quit()
        # progressbar = QProgressDialog(self.m_page.view())
        # progressbar.findChild(QProgressBar).setTextVisible(False)
        # progressbar.setLabelText("Wait please...")
        # progressbar.setRange(0, 0)
        # progressbar.show()
        # progressbar.canceled.connect(loop.quit)
        self.m_page.print(printer, printPreview)
        loop.exec_()
        # progressbar.close()
        if not result:
            painter = QPainter()
            if painter.begin(printer):
                font = painter.font()
                font.setPixelSize(20)
                painter.setFont(font)
                painter.drawText(QPointF(10, 25), "Could not generate print preview.")
                painter.end()
