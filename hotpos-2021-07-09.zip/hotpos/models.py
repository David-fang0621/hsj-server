import json
from typing import Any, List, Union

from pydantic import BaseModel
from pydantic.typing import NoneType
from PyQt5.QtWidgets import QApplication

from .config import ORDER_STATUS, ORDER_TYPES


class User(BaseModel):

    username: str
    name: str
    branch_id: int
    # ext: int
    # iat: int
    iss: str
    jti: str
    nbf: int
    # role: None
    sub: int


class Customer(BaseModel):

    id: int
    first_name: str
    last_name: str
    country_id: int
    district_id: int
    city_id: int
    phone_number: str
    address1: str
    address2: str


class City(BaseModel):

    id: int
    name: str
    district_id: int
    created_at: str
    updated_at: str


class District(BaseModel):

    id: int
    name: str
    country_id: int
    created_at: str
    updated_at: str
    city_list: Union[City, NoneType]


class Country(BaseModel):

    id: int
    name: str
    nicename: str
    iso: str
    # iso3: str
    # numcode: str
    phonecode: str
    created_at: str
    updated_at: str
    district_list: Union[District, NoneType]


class Modifier(BaseModel):

    id: int
    item_id: int
    modifier: str
    price: float
    # recipe_id: int
    created_at: str
    updated_at: str


class Promo(BaseModel):
    id: int
    name: str
    discount: int
    from_date: str
    to_date: str
    created_at: str
    updated_at: str

class AppliedModifier(BaseModel):

    qty: int
    modifiers: List[Modifier]


class AppliedPromo(BaseModel):
    promos: List[Promo]


class Image(BaseModel):

    created_at: str
    id: int
    image: str
    item_id: int
    updated_at: str


class Cookie(BaseModel):

    appliedModifiers: List[AppliedModifier]
    branch_id: int
    category_id: int
    company_id: int
    cost_center_id: int
    created_at: str
    display_order: int
    hasModifiers: bool
    hasPromos: bool
    id: int
    image: Union[str, Image]
    imagePath: str
    is_publish: int
    kitchennote: Union[str, NoneType]
    modifiers: List[Modifier]
    name: str
    price: float
    promos: List[Promo]
    qty: int
    recipe_id: Union[NoneType, int]
    selectedPromos: List[Promo]
    updated_at: str


class Customer(BaseModel):

    id: int
    first_name: str
    last_name: str
    country_id: int
    district_id: int
    city_id: int
    phone_number: str
    address1: str
    address2: str


class Discount(BaseModel):

    amount: float
    percentage: float


class OrderContent(BaseModel):
    items: List[Cookie]
    combos: List


class Order(BaseModel):

    ordercontent: OrderContent
    sub_total: float
    total: float
    tax: float
    discount: Discount
    customer: Union[Customer, NoneType]
    id: int
    type: int
    status: int
    created_at: str

    def calculate(self):
        self.sub_total = 0
        for cookie in self.ordercontent.items:
            self.sub_total += cookie.price * cookie.qty
            for modifier_collection in cookie.appliedModifiers:
                for modifier in modifier_collection.modifiers:
                    self.sub_total -= modifier.price * modifier_collection.qty
            for promo in cookie.selectedPromos:
                self.sub_total -= self.sub_total * promo.discount / 100
        self.total = float(self.sub_total)
        if self.discount.amount > self.sub_total:
            self.discount.amount = self.sub_total
        self.total = self.total - self.discount.amount
        self.total = self.total * (100 - self.discount.percentage) / 100.0
        self.total = self.total * (100.0 - self.tax) / 100.0

    def serialize(self, is_delivery=False):
        class Payload(BaseModel):
            orderid: str
            ordertype: int
            discount: Discount
            order: OrderContent
            customerid: int
            totalprice: float
            subtotalprice: float
            tax: float
            status: int

        discount = self.discount
        payload = Payload(
            orderid='#' + str(self.id),
            ordertype=self.type,  # 1 takeaway
            discount=discount,
            order=self.ordercontent,
            customerid= 0 if self.customer is None else self.customer.id,
            totalprice=self.total,
            subtotalprice=self.sub_total,
            tax=self.tax,
            status=ORDER_STATUS.NEW if is_delivery else ORDER_STATUS.PAID,
        )
        return payload.dict()

    def toHtml(self):
        html = '''
        <ul>
            <li>Order Number: ORDER_ID</li>
            <li>Type: ORDER_TYPE</li>
            <li>Date: ORDER_DATE</li>
            <li>
                Order:
                <ul>
                    ORDER_ITEMS
                </ul>
            </li>
            <li>Customer: ORDER_CUSTOMER</li>
            <li>Sub Total: ORDER_SUBTOTAL</li>
            <li>Tax: ORDER_TAX</li>
            <li>Total: ORDER_TOTAL</li>
        </ul>
        '''
        html = html.replace('ORDER_ID', str(self.id))
        html = html.replace('ORDER_TYPE', str(self.type))
        html = html.replace('ORDER_DATE', str(self.created_at))
        items_html = ''
        for cookie in self.ordercontent.items:
            items_html += '<li>%d %s</li>' % (cookie.qty, cookie.name)
        html = html.replace('ORDER_ITEMS', items_html)
        html = html.replace('ORDER_CUSTOMER', '' if self.customer is None else str(self.customer.first_name + ' ' + self.customer.last_name))
        html = html.replace('ORDER_SUBTOTAL', str(self.sub_total))
        html = html.replace('ORDER_TAX', str(self.tax))
        html = html.replace('ORDER_ID', str(self.total))
        return html

    @classmethod
    def deserialize(cls, data: dict):
        return Order(
            ordercontent=OrderContent(**json.loads(data['ordercontent'])),
            sub_total=data['subtotalprice'],
            total=data['totalprice'],
            tax=data['tax'],
            discount=Discount(**json.loads(data['discount'])),
            customer=QApplication.instance().backend().getCustomerById(data['customerid']),
            id=int(data['orderid'][1:]),
            type=data['ordertype'],
            status=data['status'],
            created_at=data['created_at'],
        )


class MainReadingInfoVisibility(BaseModel):

    show_company_name: int
    show_branch_name: int
    show_branch_address: int
    show_vat_info: int
    show_phone_number: int


class MainReadingInfo(BaseModel):

    branch_name: str
    branch_address: str
    branch_phone_number: str
    company_name: str
    company_tax_number: Union[str, NoneType]
    company_tax: float
    company_currency: str
    usd_to_lbp_rate: float
    visibility: MainReadingInfoVisibility
