from PyQt5.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QDialog, QDialogButtonBox, QGroupBox, QCheckBox, QScrollArea

from ..config import DIALOG_MIN_SIZE_B, SIZE_B
from ..models import Cookie

class AddPromosDialog(QDialog):

    def __init__(self, cookie: Cookie, parent=None):
        super().__init__(parent=parent)

        self.cookie = cookie

        self.setMinimumSize(*DIALOG_MIN_SIZE_B)
        self.setWindowTitle("Add Promos")

        root_layout = QVBoxLayout(self)

        layout = QHBoxLayout()
        root_layout.addLayout(layout)
        
        gb = QGroupBox("Promos")
        gb.setMaximumHeight(SIZE_B * 8)
        root_layout.addWidget(gb)
        gb_root = QVBoxLayout(gb)
        promo_checklist_widget = QWidget()
        promo_checklist_layout = QVBoxLayout(promo_checklist_widget)
        promo_checklist_layout.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(promo_checklist_widget)
        gb_root.addWidget(scroll)

        self.promo_checkbox_list = []
        for promo in self.cookie.promos:
            checkbox = QCheckBox(promo.name)
            checkbox.clicked.connect(self.checkApplicable)
            promo_checklist_layout.addWidget(checkbox)
            self.promo_checkbox_list.append(checkbox)

        QBtn = QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        buttonbox = QDialogButtonBox(QBtn)
        root_layout.addWidget(buttonbox)
        buttonbox.accepted.connect(self.onOkClick)
        buttonbox.rejected.connect(self.reject)

        self.renderPromoCollectionList()

    def renderPromoCollectionList(self):
        for i in range(len(self.cookie.promos)):
            if self.cookie.promos[i] in self.cookie.selectedPromos:
                self.promo_checkbox_list[i].setChecked(True)

    def onOkClick(self):
        self.accept()

    def checkApplicable(self):
        promo_list = []
        for i in range(len(self.cookie.promos)):
            if self.promo_checkbox_list[i].isChecked():
                promo_list.append(self.cookie.promos[i])
        self.cookie.selectedPromos = promo_list

