from PyQt5.QtWidgets import QApplication, QLineEdit, QPushButton, QTextEdit, QWidget, QHBoxLayout, QVBoxLayout, QDialog, QDialogButtonBox

from ..config import DIALOG_MIN_SIZE_C, ORDER_STATUS
from ..models import Order
from ..widgets.label import LabelWidget


class OrderDetailsDialog(QDialog):

    def __init__(self, order: Order, parent=None):
        super().__init__(parent=parent)
        self.app = QApplication.instance()

        self.order = order

        self.setMinimumSize(*DIALOG_MIN_SIZE_C)
        self.setWindowTitle("Order Details")

        root_layout = QVBoxLayout(self)
        root_layout.addWidget(LabelWidget(self.order.toHtml()))

        self.reason_edit = QTextEdit()
        self.reason_edit.hide()
        root_layout.addWidget(self.reason_edit)

        QBtn = QDialogButtonBox.Cancel
        buttonbox = QDialogButtonBox(QBtn)
        root_layout.addWidget(buttonbox)
        buttonbox.rejected.connect(self.reject)

        if order.status == ORDER_STATUS.PAID:
            button = buttonbox.addButton("Void", QDialogButtonBox.ActionRole)
            button.clicked.connect(self.onVoidClick)

        if order.status == ORDER_STATUS.NEW:
            button = buttonbox.addButton("Add", QDialogButtonBox.ActionRole)
            button.clicked.connect(self.onAddClick)
            button = buttonbox.addButton("Cash Out", QDialogButtonBox.ActionRole)
            button.clicked.connect(self.onCashOutClick)

        button = buttonbox.addButton("Print", QDialogButtonBox.ActionRole)
        button.setEnabled(False)

    def onAddClick(self):
        self.app.main_window.order_list_page.hide()
        self.app.main_window.take_away_page.show()
        self.app.main_window.take_away_page.order_widget.loadOrder(self.order)
        self.reject()

    def onCashOutClick(self):
        self.app.backend().cashOut(self.order.id)
        self.accept()

    def onVoidClick(self):
        if self.reason_edit.toPlainText() == '':
            self.reason_edit.show()
        else:
            self.app.backend().voidOrder(self.order.id, "no reason")
            self.accept()
