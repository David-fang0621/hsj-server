from typing import List, Union

from PyQt5.QtCore import QDateTime, QTime, Qt
from PyQt5.QtWidgets import QDateEdit, QHBoxLayout, QTimeEdit, QVBoxLayout, QDialog, QDialogButtonBox, QCompleter, QLineEdit, QComboBox
from pydantic.typing import NoneType

from ..config import DIALOG_MIN_SIZE_D
from ..models import Customer


class AddReservationDialog(QDialog):

    def __init__(self, customer_list: List[Customer], parent=None):
        super().__init__(parent=parent)

        self.customer: Union[Customer, NoneType] = None
        self.customer_list = customer_list
        self.customer_search_string_list = [self.getSearchString(c) for c in self.customer_list]
        self.table_number_list = range(1, 10)

        self.initUI()

    def initUI(self):
        self.setMinimumSize(*DIALOG_MIN_SIZE_D)
        self.setWindowTitle("New Reservation")

        root_layout = QVBoxLayout(self)

        self.search_edit = QLineEdit()
        self.completer = QCompleter(self.customer_search_string_list)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.search_edit.setCompleter(self.completer)
        self.search_edit.setPlaceholderText("Search Customer")
        self.search_edit.textChanged.connect(self.onSearchTextInput)
        root_layout.addWidget(self.search_edit)

        layout = QHBoxLayout()
        root_layout.addLayout(layout)
        self.first_name_edit = QLineEdit()
        self.first_name_edit.setPlaceholderText("First Name")
        layout.addWidget(self.first_name_edit)
        self.last_name_edit = QLineEdit()
        self.last_name_edit.setPlaceholderText("Last Name")
        layout.addWidget(self.last_name_edit)

        self.phone_number_edit = QLineEdit()
        self.phone_number_edit.setPlaceholderText("Phone Number")
        root_layout.addWidget(self.phone_number_edit)

        self.date = QDateEdit()
        self.date.setDateTime(QDateTime.currentDateTime())
        root_layout.addWidget(self.date)

        self.time = QTimeEdit()
        self.time.setTime(QTime.currentTime())
        root_layout.addWidget(self.time)

        layout = QHBoxLayout()
        root_layout.addLayout(layout)
        self.nGuest = QLineEdit()
        self.nGuest.setPlaceholderText("# 0f Guests")
        layout.addWidget(self.nGuest)
        self.table_number_combo = QComboBox()
        layout.addWidget(self.table_number_combo)

        self.table_number_combo.addItems([ str(num) for num in self.table_number_list])
        self.table_number_combo.currentIndexChanged.connect(self.onTableNumberChange)

        QBtn = QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        buttonbox = QDialogButtonBox(QBtn)
        root_layout.addWidget(buttonbox)
        buttonbox.accepted.connect(self.onOkClick)
        buttonbox.rejected.connect(self.reject)

    def onOkClick(self):
        if self.customer == None:
            print(self.first_name_edit)
        #self.app.backend().setReservation(self.order.serialize(is_delivery=is_delivery))
        self.accept()

    def onSearchTextInput(self):
        if self.search_edit.text() in self.customer_search_string_list:
            for c in self.customer_list:
                if self.search_edit.text() == self.getSearchString(c):
                    self.customer = c
                    self.showCustomer()
                    break

    def showCustomer(self):
        if self.customer is None:
            return
        self.first_name_edit.setText(self.customer.first_name)
        self.last_name_edit.setText(self.customer.last_name)
        self.phone_number_edit.setText(self.customer.phone_number)

    def onTableNumberChange(self):
        self.table_number = self.table_number_list[self.table_number_combo.currentIndex()]

    def getSearchString(self, c: Customer):
        return "%s %s -- %s" % (c.first_name, c.last_name, c.phone_number)
