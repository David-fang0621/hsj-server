from PyQt5.QtGui import QMouseEvent
from PyQt5.QtWidgets import QApplication, QPushButton, QWidget, QVBoxLayout, QGroupBox
from typing import List

from ..widgets.table import ReservationTableWidget
from ..dialogs.add_reservation import AddReservationDialog
from ..config import ITEM_ICON_SIZE
from ..models import Customer


class ReservationPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.app = QApplication.instance()
        self.customer_list: List[Customer] = []

        root_layout = QVBoxLayout(self)

        self.gb = QGroupBox("Reservation")
        root_layout.addWidget(self.gb)
        gb_root = QVBoxLayout(self.gb)
        self.reservation_table = ReservationTableWidget()
        self.btn_new_reservation = QPushButton("New Reservation")
        self.btn_new_reservation.mousePressEvent = self._openAddReservationDialog
        gb_root.addWidget(self.btn_new_reservation)
        gb_root.addWidget(self.reservation_table)
    
    def _openAddReservationDialog(self, e: QMouseEvent):
        self.customer_list = self.app.backend().getCustomerList()
        dialog = AddReservationDialog(self.customer_list)
        dialog.exec_()
