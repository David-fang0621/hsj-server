# HotPOS

Qt desktop application for POS management system.

## Quickstart

On Linux & Mac,

```
git clone https://github.com/hotteshen/hotpos
cd hotpos
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```
